package com.academik.security.beans;

import javax.faces.bean.ManagedBean;

/**
 *
 * @author esvux
 */
@ManagedBean
public class RegisterNormalUserBean {
    
}
